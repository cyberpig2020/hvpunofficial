# Unofficial HvH modifciation
 
Unofficial FoundryVTT system for Midguard RPG of Midguard System for our playing group


This will be discontinued as soon as tgere will be offical version of Heroes vs Monsters.
As I am not Fron end developer this will be not beatuifull coding too.

This is totally based on offical Midguard:

https://github.com/arturkonczalski/Midguard-RPG-Official

All credist to the authors of the Midguard system


